# 《SQL必知必会（第5版）》习题\+笔记 

## 二、章节跟书练习（含费曼） 

### 配套资料\+个人环境

- 本书讲授的SQL主要是ANSI SQL。

- 配套样例表：附录 A 提供 Customers、Orders、OrderItems、Products、Vendors 等通用零售样例库脚本（具体列名按所下脚本版本为准），可用于第2–22课全部练习。

- 图书网站：https://forta\.com/books/0135182794

- 我的环境：mysql  Ver 8\.0\.25 for Win64 on x86\_64 \(MySQL Community Server \- GPL\)  \+Workbence。 

### 第1课 

schema这个翻译不应该翻译为模式，模式在我的理解里算是一个形容词，比如说一个人有什么样的行为模式，这句话我会将模式和行为两个字结合起来，就会简单理解为习惯、惯性，但是数据库里的schema含义更多的是对表的描述，或者对整个系统的概述，更倾向于概要，而不是习惯。

对主键的理解更加深了，之前仅仅把主键当做是唯一的标识，现在还意识到主键的应用同样还要考虑到删除的记录，也就是所有的数据和行为都需要进行留痕，不仅仅是信息留痕。

- 跟书动作：看数据库/表/列/行/主键/模式定义；按附录A在本地建样例库 

### 附录A 样例表脚本

- 跟书动作：按官方脚本建 Customers/Orders/OrderItems/Products/Vendors；MySQL 常用 tysql 库，先执行建表再执行数据 

- 自建动作：记录本机DBMS、脚本来源、导入后行数校验 

- 错点/备注：阅读附录A时发现还是不能完全理解为什么订单的信息要分订单明细和订单两张表；于是找了一些其他的资料用来辅助理解，

- [规范化原则：避免数据重复 \- SQLite 数据库入门：从零到一的实战指南 \- 八股精](https://www.bagujing.com/courses/sqlite-tutorial-for-beginners-zero-to-hero~8gfmvltz0/database-normalization-principles~8gfmvlvtl)

- ***在现代计算机的性能下，JOIN 的开销通常远小于数据混乱带来的维护成本。***
***规则：表里的每一列，都必须和整个主键直接相关，而不是只跟主键的一部分相关。***

### 第2课 检索数据 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 编写 SQL 语句，从 Customers 表中检索所有的 ID（cust\_id）。|`SELECT cust_id FROM Customers;`|`SELECT cust_id FROM Customers;`|**✅**|![image\.png](图片和附件/image%2024.png)|<br>![image\.png](图片和附件/image%2078.png)|
|2\. 检索并列出已订购产品（prod\_id）的清单，只列不同产品。|`SELECT DISTINCT prod_id FROM OrderItems;`|`SELECT distinct prod_id FROM Orderitems;`|第一次**❌**<br>第二次**✅**|![image\.png](图片和附件/image%2031.png)|![image\.png](图片和附件/image%2043.png)|
|3\. 检索 Customers 所有列；再写一条只检索 cust\_id；用注释切换运行。|`SELECT * FROM Customers;`<br>`# SELECT cust_id FROM Customers;`|`/* 注释其中一条 */`<br>`-- SELECT distinct prod_id FROM Customers;`<br>`SELECT cust_id FROM Customers;`|**✅**|![image\.png](图片和附件/image%201.png)|![image\.png](图片和附件/image%2014.png)|

### 第3课 排序检索数据 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 编写 SQL 语句，从 Customers 中检索所有的顾客名称（cust\_names），并按从 Z 到 A 的顺序显示结果。|`SELECT cust_name `<br>`FROM Customers `<br>`ORDER BY cust_name DESC; `|`SElECT cust_name`<br>`FROM Customers`<br>`ORDER BY 1 DESC;`|**✅**<br>|![image\.png](图片和附件/image%2012.png)|![image\.png](图片和附件/image%2057.png)|
|2. 从 Orders 表中检索顾客 ID（cust\_id）和订单号 （order\_num），并先按顾客 ID 对结果进行排序，再按订单日期倒序 排列。|`SELECT cust_id, order_num FROM Orders ORDER BY cust_id, order_date DESC;`|`SElECT cust_id, order_num`<br>`FROM Orders`<br>`ORDER BY cust_id, order_date DESC;`|**✅**<br>|![image\.png](图片和附件/image%2013.png)|![image\.png](图片和附件/image%2018.png)|
|3. 显然，我们的虚拟商店更喜欢出售比较贵的物品，而且这类物品有很多。编写 SQL 语句，显示 OrderItems 表中的数量和价格（item\_price），并按数量由多到少、价格由高到低排序。|`SELECT quantity, item_price `<br>`FROM OrderItems `<br>`ORDER BY quantity DESC, item_price DESC;`|`SElECT quantity, item_price`<br>`FROM Orderitems`<br>`ORDER BY quantity DESC,item_price DESC;`|**✅**|![image\.png](图片和附件/image%2038.png)|![image\.png](图片和附件/image%2073.png)|
|4. 下面的 SQL 语句有问题吗？（尝试在不运行的情况下指出。）<br>`SELECT vend_name,`<br>`FROM Vendors`<br>`ORDER vend_name DESC;`|vend\_name 后不应有逗号（逗号仅用于分隔多个列），并且 ORDER 后<br>缺少了 BY。|`ORDER` 后少了`By` 且，`vend_name,`后多了一个`,`，应该是<br>`SELECT vend_name`<br>`FROM Vendors`<br>`ORDER By vend_name DESC;`|第一次**❌**<br>第二次**✅**|![image\.png](图片和附件/image%203.png)|![image\.png](图片和附件/image%2048.png)|

### 第4课 过滤数据  

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 编写 SQL 语句，从 Products 表中检索产品 ID（prod\_id）和产品名称（prod\_name），只返回价格为 9\.49 美元的产品。|`SELECT prod_id, prod_name `<br>`FROM Products `<br>`WHERE prod_price = 9.49;`|`SELECT prod_id, prod_name`<br>`FROM products`<br>`where prod_price = 9.49;`|**✅**|![image\.png](图片和附件/image%2037.png)|![image\.png](图片和附件/image%2056.png)|
|2. 编写 SQL 语句，从 Products 表中检索产品 ID（prod\_id）和产品名称（prod\_name），只返回价格为 9 美元或更高的产品。|`SELECT prod_id, prod_name `<br>`FROM Products `<br>`WHERE prod_price >= 9;`|`SELECT prod_id, prod_name`<br>`FROM products`<br>`where prod_price >= 9;`|**✅**|![image\.png](图片和附件/image%2047.png)|![image\.png](图片和附件/image%2075.png)|
|3. 结合第 3 课和第 4 课编写 SQL 语句，从 OrderItems 表中检索出所有不同订单号（order\_num），其中包含 100 个或更多的产品。|`SELECT DISTINCT order_num `<br>`FROM OrderItems `<br>`WHERE quantity >=100; `|`SELECT distinct order_num`<br>`FROM Orderitems`<br>`where quantity >= 100;`|**✅**|![image\.png](图片和附件/image%2059.png)|![image\.png](图片和附件/image%207.png)|
|4. 编写 SQL 语句，返回 Products 表中所有价格在 3 美元到 6 美元之间的产品的名称（prod\_name）和价格（prod\_price），然后按价格对结果进行排序。（本题有多种解决方案，我们在下一课再讨论，不过你可以使用目前已学的知识来解决它。）|`SELECT prod_name, prod_price `<br>`FROM products `<br>`WHERE prod_price BETWEEN 3 AND 6 `<br>`ORDER BY prod_price; `|`SELECT distinct prod_name,prod_price`<br>`FROM products`<br>`WHERE prod_price BETWEEN 3 AND 6`<br>`ORDER BY prod_price;`|**✅**<br>|![image\.png](图片和附件/image%2080.png)|![image\.png](图片和附件/image%2030.png)|

### 第5课 高级数据过滤 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 编写 SQL 语句，从 Vendors 表中检索供应商名称（vend\_name），仅返回加利福尼亚州的供应商（这需要按国家\[USA\]和州\[CA\]进行过滤， 没准其他国家也存在一个加利福尼亚州）。提示：过滤器需要匹配字 符串。|`SELECT vend_name FROM Vendors WHERE vend_country = 'USA' AND vend_state = 'CA';`|`SELECT vend_name`<br>`FROM Vendors`<br>`WHERE vend_country IN ('USA','CA')`|**✅**|![image\.png](图片和附件/image%204.png)|![image\.png](图片和附件/image%2040.png)|
|2. 编写 SQL 语句，查找所有至少订购了总量 100 个的 BR01、BR02 或 BR03 的订单。你需要返回 OrderItems 表的订单号（order\_num）、 产品 ID（prod\_id）和数量，并按产品 ID 和数量进行过滤。提示： 根据编写过滤器的方式，可能需要特别注意求值顺序。|`--解法 1 `<br>`SELECT order_num, prod_id, quantity FROM OrderItems WHERE (prod_id='BR01' OR prod_id='BR02' OR prod_id='BR03')  AND quantity >=100; `<br>`--解法 2 `<br>`SELECT order_num, prod_id, quantity FROM OrderItems WHERE prod_id IN ('BR01','BR02','BR03')  AND quantity >=100;`|`SELECT order_num, prod_id`<br>`FROM OrderItems`<br>`WHERE quantity >= 100 AND prod_id IN ('BR01','BR02','BR03');`|**✅**|![image\.png](图片和附件/image%2035.png)|![image\.png](图片和附件/image%2025.png)|
|3. 现在，我们回顾上一课的挑战题。编写 SQL 语句，返回所有价格在 3 美元到 6美元之间的产品的名称（prod\_name）和价格（prod\_price）。 使用 AND，然后按价格对结果进行排序。|`SELECT prod_name, prod_price FROM products WHERE prod_price >= 3 AND prod_price <= 6 ORDER BY prod_price;`|`SELECT prod_name, prod_price`<br>`FROM Products`<br>`WHERE prod_price >= 3 AND prod_price <= 6`<br>`ORDER BY prod_price;`|**✅**|![image\.png](图片和附件/image%2067.png)|![image\.png](图片和附件/image%2027.png)|
|4. 下面的 SQL 语句有问题吗？（尝试在不运行的情况下指出。） <br>`SELECT vend_name FROM Vendors ORDER BY vend_name WHERE vend_country = 'USA' AND vend_state = 'CA'; `|ORDER BY 必须跟在 WHERE 子句之后。|ORDER BY要在WHERE之后，AND改成OR|**✅**|![image\.png](图片和附件/image%2045.png)<br>![image\.png](图片和附件/image%2060.png)<br>|![image\.png](图片和附件/image%2015.png)<br>![image\.png](图片和附件/image%2061.png)|

### 第6课 用通配符过滤 

- 跟书动作：LIKE、%、\_、部分库支持 \[\] 

- 书后挑战题：原书第6课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 编写 SQL 语句，从 Products 表中检索产品名称（prod\_name）和描 述（prod\_desc），仅返回描述中包含 toy 一词的产品。|`SELECT prod_name, prod_desc FROM Products WHERE prod_desc LIKE '%toy%';`|`SELECT prod_name, prod_desc`<br>`FROM Products`<br>`WHERE prod_desc like '%toy%';`|**✅**|![image\.png](图片和附件/image%2062.png)|![image\.png](图片和附件/image%2074.png)|
|2. 反过来再来一次。编写 SQL 语句，从 Products 表中检索产品名称（prod\_name）和描述（prod\_desc），仅返回描述中未出现 toy 一词的产品。这次，按产品名称对结果进行排序。|`SELECT prod_name, prod_desc `<br>`FROM Products `<br>`WHERE NOT prod_desc LIKE '%toy%' `<br>`ORDER BY prod_name;`|`SELECT prod_name, prod_desc`<br>`FROM Products`<br>`WHERE NOT prod_desc like '%toy%'`<br>`ORDER BY prod_name;`|**✅**|![image\.png](图片和附件/image%2029.png)|![image\.png](图片和附件/image%2050.png)|
|3. 编写 SQL 语句，从 Products 表中检索产品名称（prod\_name）和描述（prod\_desc），仅返回描述中同时出现 toy 和 carrots 的产品。有好几种方法可以执行此操作，但对于这个挑战题，请使用 AND 和两个 LIKE 比较。|`SELECT prod_name, prod_desc `<br>`FROM Products `<br>`WHERE prod_desc LIKE '%toy%' AND prod_desc LIKE '%carrots%'; `|`SELECT prod_name, prod_desc`<br>`FROM Products`<br>`WHERE prod_desc like '%toy%'`<br>`AND prod_desc like '%carrots%';`|**✅**|![image\.png](图片和附件/image%2036.png)|![image\.png](图片和附件/image%2070.png)|
|4. 来个比较棘手的。我没有特别向你展示这个语法，而是想看看你根据目前已学的知识是否可以找到答案。编写 SQL 语句，从 Products 表中检索产品名称（prod\_name）和描述（prod\_desc），仅返回在描述中以先后顺序同时出现 toy 和 carrots 的产品。提示：只需要用带有三个 % 符号的 LIKE 即可。|`SELECT prod_name, prod_desc `<br>`FROM Products `<br>`WHERE prod_desc LIKE '%toy%carrots%'; `|`SELECT prod_name, prod_desc`<br>`FROM Products`<br>`WHERE prod_desc like '%toy%carrots%';`|**✅**|![image\.png](图片和附件/image%2063.png)|![image\.png](图片和附件/image%2058.png)|

- 错点：前导 % 通常不利索引；\[\] 仅部分 DBMS 支持，跨库用正则或函数替代。 

- 费曼自测： 

    1. 人话：模糊匹配，适合只知道部分名称时找数据。 

    2. 绕路：全量导出用 Excel 包含筛选，但大数据慢。 

    3. 业务：按“牛仔”“通勤”“老钱风”等关键词搜产品名做选品初筛。 

### 第7课 创建计算字段 

- 跟书动作：拼接、别名、算术计算 、SELECT 后不接FROM可以用于检验语法；

- 书后挑战题：原书第7课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 别名的常见用法是在检索出的结果中重命名表的列字段（为了符合特定的报表要求或客户需求）。编写 SQL 语句，从 Vendors 表中检索vend\_id、vend\_name、vend\_address 和 vend\_city，将 vend\_name重命名为 vname，将 vend\_city 重命名为 vcity，将 vend\_address重命名为 vaddress。按供应商名称对结果进行排序（可以使用原始名称或新的名称）。|`SELECT vend_id,`<br>`vend_name as vname,`<br>`vend_address AS vaddress,`<br>`vend_city AS vcity `<br>`FROM Vendors `<br>`ORDER BY vname;`|`SELECT vend_id,`<br>`vend_name AS vname,`<br>`vend_address AS vaddress,`<br>`vend_city AS vcity`<br>`FROM Vendors`<br>`ORDER BY vname;`|**✅**|![image\.png](图片和附件/image%2068.png)|0\.016s|
|2. 我们的示例商店正在进行打折促销，所有产品均降价 10%。编写 SQL语句，从 Products 表中返回 prod\_id、prod\_price 和 sale\_price。sale\_price 是一个包含促销价格的计算字段。提示：可以乘以 0\.9，得到原价的 90%（即 10%的折扣）。|`SELECT prod_id, prod_price,  prod_price * 0.9 AS sale_price FROM Products;`<br><br>|`SELECT prod_id,`<br>`prod_price,`<br>`prod_price * 0.9 AS sale_price`<br>`FROM Products;`|**✅**|![image\.png](图片和附件/image%206.png)|0\.000s|

- 错点：拼接函数随库变；计算字段不物理存表，通常只用于结果集。 

- 费曼自测： 

    1. 人话：查询时临时算出新列，比如金额、全称、折扣价。 

    2. 绕路：取出原始列用 Excel 算，但不利于自动化。 

    3. 业务：GMV、毛利估算、客单价、折扣后实付都靠计算字段。 

### 第8课 使用函数处理数据 

- 跟书动作：文本/日期/数值函数；注意可移植性 

- 书后挑战题：原书第8课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 我们的商店已经上线了，正在创建顾客账户。所有用户都需要登录名，默认登录名是其名称和所在城市的组合。编写 SQL 语句，返回顾客 ID（cust\_id）、顾客名称（customer\_name）和登录名（user\_login），其中登录名全部为大写字母，并由顾客联系人的前两个字符（cust\_ contact）和其所在城市的前三个字符（cust\_city）组成。例如，我的登录名是 BEOAK（Ben Forta，居住在 Oak Park）。提示：需要使用函数、拼接和别名。|`-- MySQL `<br>`SELECT cust_id, cust_name,`<br>`CONCAT(UPPER(LEFT(cust_contact, 2)), UPPER(LEFT(cust_city, 3))) AS`<br>`user_login `<br>`FROM customers; `|`SELECT cust_id,cust_name,`<br>`UPPER(CONCAT(LEFT(cust_contact,2), LEFT(cust_city,3))) AS user_login`<br>`FROM Customers;`|**✅**|![image\.png](图片和附件/image%2041.png)|0\.000s|
|2. 编写 SQL 语句，返回 2020 年 1 月的所有订单的订单号（order\_num）和订单日期（order\_date），并按订单日期排序。你应该能够根据目前已学的知识来解决此问题，但也可以开卷查阅 DBMS 文档。|`SELECT order_num, order_date `<br>`FROM Orders `<br>`WHERE YEAR(order_date) = 2020 AND MONTH(order_date) = 1 `<br>`ORDER BY order_date; `|`SELECT order_num, order_date`<br>`FROM Orders`<br>`WHERE YEAR(order_date) = 2020 AND MONTH(order_date) = 1`<br>`ORDER BY order_date`|**✅**|![image\.png](图片和附件/image%2032.png)|0\.000s|

- 错点：函数可移植性差；日期函数在 MySQL/SQL Server/Oracle/PG 差异大，业务脚本要按库固化。 

- 费曼自测： 

    1. 人话：函数像Excel公式，处理文本、时间、数字。 

    2. 绕路：取原始数据在外部处理，但重复取数成本高。 

    3. 业务：按“月/周/季节”拆销售、按文本提取品类标签都靠函数。 

### 第9课 汇总数据 

- 跟书动作：COUNT/SUM/AVG/MIN/MAX、DISTINCT 聚集 

- 书后挑战题：原书第9课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 编写 SQL 语句，确定已售出产品的总数（使用 OrderItems 中的quantity 列）。|`SELECT SUM(quantity) AS items_ordered`<br>`FROM OrderItems; `|`SELECT SUM(quantity) AS quantities`<br>`FROM OrderItems;`|**✅**|![image\.png](图片和附件/image%2023.png)|0\.016s|
|2. 修改刚刚创建的语句，确定已售出产品项（prod\_item）BR01 的总数。|`SELECT SUM(quantity) AS items_ordered`<br>`FROM OrderItems`<br>`WHERE prod_id = 'BR01';`|`SELECT SUM(quantity) AS quantities`<br>`FROM OrderItems`<br>`WHERE prod_id = 'BR01';`|**✅**<br>|![image\.png](图片和附件/image%209.png)|0\.000s|
|3. 编写 SQL 语句，确定 Products 表中价格不超过 10 美元的最贵产品的价格（prod\_price）。将计算所得的字段命名为 max\_price。|`SELECT MAX(prod_price) AS max_price`<br>`FROM Products`<br>`WHERE prod_price <= 10; `|`SELECT MAX(prod_price) AS max_price`<br>`FROM Products`<br>`WHERE prod_price <= 10;`|**✅**|![image\.png](图片和附件/image%2019.png)|0\.000s|

- 费曼自测： 

    1. 人话：聚集函数把多行算成一个统计值。 

    2. 绕路：Excel 透视可替代小规模，但SQL可定时复用。 

    3. 业务：GMV、订单数、均价、库存金额都来自聚集。 

### 第10课 分组数据 

- 跟书动作：GROUP BY、HAVING、SELECT 子句顺序 

- 书后挑战题：原书第10课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. OrderItems 表包含每个订单的每个产品。编写 SQL 语句，返回每个 订单号（order\_num）各有多少行数（order\_lines），并按 order\_lines 对结果进行排序。|`SELECT order_num, COUNT(*) as order_lines FROM OrderItems GROUP BY order_num ORDER BY order_lines;`|`SELECT order_num, COUNT(*) AS order_lines`<br>`FROM OrderItems`<br>`GROUP BY order_num`<br>`ORDER BY order_lines`|**✅**|![image\.png](图片和附件/image%2051.png)|0\.156s|
|2. 编写 SQL 语句，返回名为 cheapest\_item 的字段，该字段包含每个 供应商成本最低的产品（使用 Products 表中的 prod\_price），然后 从最低成本到最高成本对结果进行排序。|`SELECT vend_id, MIN(prod_price) AS cheapest_item FROM Products GROUP BY vend_id ORDER BY cheapest_item;`|`SELECT vend_id, MIN(prod_price) AS cheapest_item`<br>`FROM Products`<br>`GROUP BY vend_id`<br>`ORDER BY cheapest_item`|**✅**|![image\.png](图片和附件/image%2011.png)<br>|0\.015s|
|3. 确定最佳顾客非常重要，请编写 SQL 语句，返回至少含 100 项的所有 订单的订单号（OrderItems 表中的 order\_num）。|`SELECT order_num FROM OrderItems GROUP BY order_num HAVING SUM(quantity) >= 100 ORDER BY order_num;`|`SELECT order_num`<br>`FROM OrderItems`<br>`GROUP BY order_num`<br>`HAVING SUM(quantity) >= 100`|**✅**|![image\.png](图片和附件/image%2017.png)|0\.015s|
|4. 确定最佳顾客的另一种方式是看他们花了多少钱。编写 SQL 语句， 返回总价至少为 1000 的所有订单的订单号（OrderItems 表中的 order\_num）。提示：需要计算总和（item\_price 乘以 quantity）。 按订单号对结果进行排序。|`SELECT order_num, SUM(item_price*quantity) AS total_price FROM OrderItems GROUP BY order_num HAVING SUM(item_price*quantity) >= 1000 ORDER BY order_num;`|`SELECT order_num`<br>`FROM OrderItems`<br>`GROUP BY order_num`<br>`HAVING SUM(item_price*quantity) >= 1000`<br>`ORDER BY order_num`|**✅**|![image\.png](图片和附件/image%2044.png)<br>|0\.015s|
|5. 下面的 SQL 语句有问题吗？（尝试在不运行的情况下指出。） <br>`SELECT order_num, COUNT(*) AS items FROM OrderItems GROUP BY items HAVING COUNT(*) >= 3 ORDER BY items, order_num;` |`GROUP BY` 项是错误的。`GROUP BY` 必须是实际列，而不是用于执行汇总计算的列。允许使用 `GROUP BY order_num`。|`GROUP BY` 后不可以接items。|**✅**|![image\.png](图片和附件/image%2028.png)|0\.0000s|

- 错点：SELECT 非聚集列必须进 GROUP BY；WHERE 先筛行、HAVING 后筛组。 

- 费曼自测： 

    1. 人话：按某个维度归类后再算合计/均值。 

    2. 绕路：先查出明细再用Excel分组，但自动化差。 

    3. 业务：按品类/价格带/门店/渠道算售罄率、GMV、库存金额都靠它。 

### 第11课 使用子查询 

- 跟书动作：嵌套 SELECT、IN 子查询、作为计算字段的相关子查询 

- 书后挑战题：原书第11课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 使用子查询，返回购买价格为 10 美元或以上产品的顾客列表。你需要使用 OrderItems 表查找匹配的订单号（order\_num），然后使用Order 表检索这些匹配订单的顾客 ID（cust\_id）。|`SELECT cust_id FROM Orders WHERE order_num IN (SELECT order_num  FROM OrderItems  WHERE item_price >= 10);`|`SELECT cust_id`<br>`FROM Orders`<br>`WHERE order_num IN(`<br>`SELECT order_num`<br>`FROM OrderItems`<br>`WHERE item_price >= 10`<br>`);`|**✅**|![image\.png](图片和附件/image%208.png)|0\.125s|
|2. 你想知道订购 BR01 产品的日期。编写 SQL 语句，使用子查询来确定哪些订单（在 OrderItems 中）购买了 prod\_id 为 BR01 的产品，然后从 Orders 表中返回每个产品对应的顾客 ID（cust\_id）和订单日期（order\_date）。按订购日期对结果进行排序。|`SELECT cust_id, order_date FROM orders WHERE order_num IN (SELECT order_num  FROM OrderItems  WHERE prod_id = 'BR01') ORDER BY order_date;`|`SELECT cust_id, order_date`<br>`FROM Orders`<br>`WHERE order_num IN(`<br>`SELECT order_num`<br>`FROM OrderItems`<br>`WHERE prod_id ='BR01'`<br>`)`<br>`ORDER BY order_date;`|**✅**|![image\.png](图片和附件/image%2042.png)|0\.000s|
|3. 现在我们让它更具挑战性。在上一个挑战题，返回购买 prod\_id 为BR01 的产品的所有顾客的电子邮件（Customers 表中的 cust\_email）。提示：这涉及 SELECT 语句，最内层的从 OrderItems 表返回 order\_num，中间的从 Customers 表返回 cust\_id。|`SELECT cust_email FROM Customers WHERE cust_id IN (SELECT cust_id  FROM Orders  WHERE order_num IN (SELECT order_num  FROM OrderItems  WHERE prod_id = 'BR01'));`|`SELECT cust_email`<br>`FROM Customers`<br>`WHERE cust_id IN(`<br>`SELECT cust_id`<br>`FROM Orders`<br>`WHERE order_num IN(`<br>`SELECT order_num`<br>`FROM OrderItems`<br>`WHERE prod_id ='BR01'`<br>`)`<br>`);`|**✅**|![image\.png](图片和附件/image%2055.png)|0\.016s|
|4. 我们需要一个顾客 ID 列表，其中包含他们已订购的总金额。编写 SQL语句，返回顾客 ID（Orders 表中的 cust\_id），并使用子查询返回total\_ordered 以便返回每个顾客的订单总数。将结果按金额从大到小排序。提示：你之前已经使用 SUM\(\)计算订单总数。|`SELECT cust_id,`<br>`(SELECT SUM(item_price*quantity)`<br>`FROM OrderItems`<br>`WHERE Orders.order_num = OrderItems.order_num) AS total_ordered`<br>`FROM Orders`<br>`ORDER BY total_ordered DESC;`|`SELECT cust_id,`<br>`(SELECT SUM(item_price*quantity)`<br>`FROM OrderItems`<br>`WHERE Orders.order_num = OrderItems.order_num) AS total_ordered`<br>`FROM Orders`<br>`ORDER BY total_ordered DESC;`|**✅**|![image\.png](图片和附件/image%2021.png)|0\.000s|
|5. 再来。编写 SQL 语句，从 Products 表中检索所有的产品名称（prod\_name），以及名为 quant\_sold 的计算列，其中包含所售产品的总数（在 OrderItems 表上使用子查询和 SUM\(quantity\)检索）。|`SELECT prod_name,  (SELECT Sum(quantity)  FROM OrderItems  WHERE Products.prod_id=OrderItems.prod_id) AS quant_sold FROM Products; `|`SELECT prod_name,`<br>`(SELECT SUM(quantity)`<br>`FROM OrderItems`<br>`WHERE Products.prod_id = OrderItems.prod_id) AS quant_sold`<br>`FROM Products;`|**✅**|![image\.png](图片和附件/image%2054.png)<br>|0\.015s|

- 运行结果： 

- 错点：相关子查询要绑别名；大数据量可比较 JOIN 性能。 

- 费曼自测： 

    1. 人话：把一个查询结果当另一个查询的条件或列。 

    2. 绕路：分两步查再手工合并，但容易错且慢。 

    3. 业务：按用户算历史总额、按订单算金额、按品类筛达标名单都用子查询。 

### 第12课 联结表 

- 跟书动作：内连接、ON、多表别名 

- 书后挑战题：原书第12课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 编写 SQL 语句，返回 Customers 表中的顾客名称（cust\_name）和Orders 表中的相关订单号（order\_num），并按顾客名称再按订单号对结果进行排序。实际上是尝试两次，一次使用简单的等联结语法，一次使用 INNER JOIN。|`SELECT cust_name, order_num FROM Customers INNER JOIN Orders  ON Customers.cust_id = Orders.cust_id ORDER BY cust_name, order_num;`|`SELECT cust_name,order_num`<br>`FROM Customers,Orders`<br>`WHERE Customers.cust_id = Orders.cust_id`<br>`ORDER BY cust_name,order_num;`|**✅**|![image\.png](图片和附件/image%2039.png)|0\.000s/0\.015s|
|2. 我们来让上一题变得更有用些。除了返回顾客名称和订单号，添加第 三列 OrderTotal，其中包含每个订单的总价。有两种方法可以执行 此操作：使用 OrderItems 表的子查询来创建 OrderTotal 列，或者 将 OrderItems 表与现有表联结并使用聚合函数。提示：请注意需要 使用完全限定列名的地方。|`SELECT cust_name,  order_num,  (SELECT Sum(item_price*quantity)  FROM OrderItems  WHERE Orders.order_num=OrderItems.order_num) AS OrderTotal FROM Customers, Orders WHERE Customers.cust_id = Orders.cust_id ORDER BY cust_name, order_num; `|`SELECT cust_name,Orders.order_num,`<br>`SUM(item_price*quantity) AS OrderTotal`<br>`FROM Customers`<br>`INNER JOIN Orders`<br>`ON Customers.cust_id = Orders.cust_id`<br>`INNER JOIN OrderItems`<br>`ON Orders.order_num = OrderItems.order_num`<br>`GROUP BY cust_name,Orders.order_num `<br>`ORDER BY cust_name,order_num;`|**✅**|![image\.png](图片和附件/image%2016.png)<br>|0\.000s/0\.000s|
|3. 我们重新看一下第 11 课的挑战题 2。编写 SQL 语句，检索订购产品 BR01 的日期，这一次使用联结和简单的等联结语法。输出应该与第 11 课的输出相同。|`SELECT cust_id, order_date FROM Orders, OrderItems WHERE Orders.order_num = OrderItems.order_num  AND prod_id = 'BR01' ORDER BY order_date;`|`SELECT Orders.cust_id,Orders.order_date`<br>`FROM Orders,OrderItems`<br>`WHERE Orders.order_num = OrderItems.order_num`<br>`AND prod_id = 'BR01'`<br>`-- GROUP BY cust_name,Orders.order_num `<br>`ORDER BY order_date;`|**✅**|![image\.png](图片和附件/image%2049.png)|0\.016s|
|4. 很有趣，我们再试一次。重新创建为第 11 课挑战题 3 编写的 SQL 语 句，这次使用 ANSI 的 INNER JOIN 语法。在之前编写的代码中使用 了两个嵌套的子查询。要重新创建它，需要两个 INNER JOIN 语句， 每个语句的格式类似于本课讲到的 INNER JOIN 示例，而且不要忘记 WHERE 子句可以通过 prod\_id 进行过滤|`SELECT cust_email FROM Customers  INNER JOIN Orders ON Customers.cust_id = Orders.cust_id  INNER JOIN OrderItems ON Orders.order_num = OrderItems.order_num WHERE prod_id = 'BR01';`|`SELECT Customers.cust_email`<br>`FROM Customers`<br>`INNER JOIN Orders`<br>`ON Customers.cust_id = Orders.cust_id`<br>`INNER JOIN OrderItems`<br>`ON OrderItems.order_num = Orders.order_num`<br>`WHERE prod_id = 'BR01';`|**✅**|![image\.png](图片和附件/image%2026.png)<br>|0\.015s|
|5. 再让事情变得更加有趣些，我们将混合使用联结、聚合函数和分组。 准备好了吗？回到第 10 课，当时的挑战是要求查找值等于或大于 1000 的所有订单号。这些结果很有用，但更有用的是订单数量至少达到 这个数的顾客名称。因此，编写 SQL 语句，使用联结从 Customers 表返回顾客名称（cust\_name），并从 OrderItems 表返回所有订单的 总价。 提示：要联结这些表，还需要包括 Orders 表（因为 Customers 表 与 OrderItems 表不直接相关，Customers 表与 Orders 表相关，而 Orders 表与 OrderItems 表相关）。不要忘记 GROUP BY 和 HAVING， 并按顾客名称对结果进行排序。你可以使用简单的等联结或 ANSI 的 INNER JOIN 语法。或者，如果你很勇敢，请尝试使用两种方式编写。|`SELECT cust_name, SUM(item_price*quantity) AS total_price FROM Customers, Orders, OrderItems WHERE Customers.cust_id = Orders.cust_id  AND Orders.order_num = OrderItems.order_num GROUP BY cust_name HAVING SUM(item_price*quantity) >= 1000 ORDER BY cust_name; `|`SELECT cust_name,SUM(item_price*quantity) AS Total_Orderd`<br>`FROM Customers,Orders,OrderItems`<br>`WHERE Customers.cust_id = Orders.cust_id`<br>`AND Orders.order_num = OrderItems.order_num`<br>`GROUP BY cust_name`<br>`HAVING Total_Orderd >= 1000;`|**✅**|![image\.png](图片和附件/image%2077.png)|0\.016s|

- 运行结果： 

- 错点：忘 ON 会笛卡尔积；重名列必须用表别名限定。 

- 费曼自测： 

    1. 人话：多张表有关联字段时，用JOIN把行拼成宽表。 

    2. 绕路：分别查再VLOOKUP，但SQL可复用、可处理大数据。 

    3. 业务：订单碰产品、碰客户、碰库存，几乎每个取数都要JOIN。 

### 第13课 创建高级联结 

- 跟书动作：表别名、自连接、外连接、带聚集的联结 

- 书后挑战题：原书第13课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 使用 INNER JOIN 编写 SQL语句，以检索每个顾客的名称（Customers 表中的 cust\_name）和所有的订单号（Orders 表中的 order\_num）。|`SELECT cust_name, order_num FROM Customers JOIN Orders ON Customers.cust_id = Orders.cust_id ORDER BY cust_name; `|`SELECT Customers. cust_name,Orders.order_num`<br>`FROM Customers`<br>`INNER JOIN Orders`<br>`ON Customers.cust_id = Orders.cust_id;`|**✅**|![image\.png](图片和附件/image%2065.png)|0\.000s|
|2. 修改刚刚创建的 SQL 语句，仅列出所有顾客，即使他们没有下过 订单。|`SELECT cust_name, order_num FROM Customers  LEFT OUTER JOIN Orders ON Customers.cust_id = Orders.cust_id ORDER BY cust_name; `|`SELECT Customers.cust_name`<br>`FROM Customers`<br>`LEFT JOIN Orders`<br>`ON Customers.cust_id = Orders.cust_id`<br>`ORDER BY Customers.cust_name;`|**✅**|![image\.png](图片和附件/image%2066.png)<br>|0\.000s|
|3. 使用 OUTER JOIN 联结 Products 表和 OrderItems 表，返回产品名 称（prod\_name）和与之相关的订单号（order\_num）的列表，并按 商品名称排序。|`SELECT prod_name, order_num `<br>`FROM Products LEFT OUTER JOIN OrderItems `<br>`ON Products.prod_id = OrderItems.prod_id `<br>`ORDER BY prod_name;`<br>|`SELECT Products.prod_name,Orderitems.order_num`<br>`FROM Products`<br>`FULL JOIN OrderItems`<br>`ON Products.prod_id = OrderItems.prod_id`<br>`ORDER BY Products.prod_name;`|**✅**|![image\.png](图片和附件/image%202.png)|0\.000s|
|4. 修改上一题中创建的 SQL 语句，使其返回每一项产品的总订单数（不是订单号）。|`SELECT prod_name, COUNT(order_num) AS orders `<br>`FROM Products LEFT OUTER JOIN OrderItems `<br>`ON Products.prod_id = OrderItems.prod_id `<br>`GROUP BY prod_name `<br>`ORDER BY prod_name;`|`SELECT prod_name,COUNT(order_num)`<br>`FROM Products LEFT OUTER JOIN OrderItems `<br>`ON Products.prod_id = OrderItems.prod_id `<br>`GROUP BY prod_name`<br>`ORDER BY prod_name; `|**✅**|![image\.png](图片和附件/image%2076.png)|0\.000s|
|5. 编写 SQL语句，列出供应商（Vendors 表中的 vend\_id）及其可供产品的数量，包括没有产品的供应商。你需要使用 OUTER JOIN 和 COUNT\(\)聚合函数来计算 Products 表中每种产品的数量。注意：vend\_id 列会显示在多个表中，因此在每次引用它时都需要完全限定它。|`SELECT Vendors.vend_id, COUNT(prod_id) `<br>`FROM Vendors `<br>`LEFT OUTER JOIN Products ON Vendors.vend_id = Products.vend_id `<br>`GROUP BY Vendors.vend_id; `|`SELECT Vendors.vend_id, COUNT(Products.prod_id) AS Total_Prods`<br>`FROM Vendors `<br>`LEFT OUTER JOIN Products `<br>`ON Vendors.vend_id = Products.vend_id`<br>`GROUP BY Vendors.vend_id`<br>`ORDER BY Vendors.vend_id; `|**✅**|![image\.png](图片和附件/image%2072.png)|0\.016s|

- 运行结果： 

- 错点：外连接方向决定保留哪一侧全量；自连接要起不同别名。 

- 费曼自测： 

    1. 人话：高级JOIN解决“自己比自己”“保留没数据的那一侧”“关联后还汇总”。 

    2. 绕路：多次查询在Excel拼，但容易丢无订单客户。 

    3. 业务：门店无销售、商品同供应商替代、客户未下单复盘都靠外连接/自连接。 

### 第14课 组合查询 

- 跟书动作：UNION/UNION ALL、列数类型一致、排序 

- 书后挑战题：原书第14课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 编写 SQL 语句，将两个 SELECT 语句结合起来，以便从 OrderItems 表中检索产品 ID（prod\_id）和 quantity。其中，一个 SELECT 语 句过滤数量为 100 的行，另一个 SELECT 语句过滤 ID 以 BNBG 开头的 产品。按产品 ID 对结果进行排序。|`SELECT prod_id, quantity FROM OrderItems WHERE quantity = 100 UNION SELECT prod_id, quantity FROM OrderItems WHERE prod_id LIKE 'BNBG%' ORDER BY prod_id; `|`SELECT prod_id, quantity`<br>`FROM OrderItems`<br>`WHERE quantity = 100`<br>`UNION `<br>`SELECT prod_id, quantity`<br>`FROM OrderItems`<br>`WHERE prod_id = 'BNBG%'`<br>`ORDER BY prod_id; `|**✅**|![image\.png](图片和附件/image%2053.png)|0\.062s|
|2. 重写刚刚创建的 SQL 语句，仅使用单个 SELECT 语句。|`SELECT prod_id, quantity FROM OrderItems WHERE quantity = 100 OR prod_id LIKE 'BNBG%' ORDER BY prod_id; `|`SELECT prod_id, quantity`<br>`FROM OrderItems`<br>`WHERE quantity = 100`<br>`OR prod_id = 'BNBG%'`<br>`ORDER BY prod_id; `|**✅**|![image\.png](图片和附件/image%2079.png)|0\.000s|
|3. 我知道这有点荒谬，但这节课中的一个注释提到过。编写 SQL 语句， 组合 Products 表中的产品名称（prod\_name）和 Customers 表中的 顾客名称（cust\_name）并返回，然后按产品名称对结果进行排序。|`SELECT prod_name FROM Products UNION SELECT cust_name FROM Customers ORDER BY prod_name;  `|`SELECT prod_name`<br>`FROM Products`<br>`UNION`<br>`SELECT cust_name`<br>`FROM Customers`<br>`ORDER BY prod_name; `|**✅**|![image\.png](图片和附件/image.png)|0\.000s|
|4. 下面的 SQL 语句有问题吗？（尝试在不运行的情况下指出。） <br>`SELECT cust_name, cust_contact, cust_email FROM Customers WHERE cust_state = 'MI' ORDER BY cust_name; UNION SELECT cust_name, cust_contact, cust_email FROM Customers WHERE cust_state = 'IL'ORDER BY cust_name;  `|第一个 `SELECT` 语句后的;不应该出现，它将终止该语句。同样，如果 将结合 `UNION` 的 `SELECT` 语句进行排序，则只能使用一个 `ORDER BY`， 并且它必须跟在最后一个 `SELECT` 之后。<br>|`ORDER BY` 放在最后一条`SELECT`语句的最后，并且只需要一句就可；<br>|**✅**|![image\.png](图片和附件/image%2069.png)|0\.000s|

- 运行结果： 

- 错点：各段列数、顺序、类型要一致；UNION ALL 不去重更快。 

- 费曼自测： 

    1. 人话：把多个查询结果上下拼成一张表。 

    2. 绕路：分别查再复制粘贴，但重复行和自动化都麻烦。 

    3. 业务：合并多价格带、多平台、多门店取数结果做总表。 

### 第15课 插入数据 

- 跟书动作：INSERT、指定列插入、INSERT SELECT、复制表 

- 书后挑战题：原书第15课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 使用 INSERT 和指定的列，将你自己添加到 Customers 表中。明确列 出要添加哪几列，且仅需列出你需要的列。|`-- 显然要用你自己的内容替换。 INSERT INTO Customers(cust_id,  cust_name,  cust_address,  cust_city,  cust_state,  cust_zip,  cust_country,  cust_email) VALUES(1000000042,  'Ben''s Toys',  '123 Main Street',  'Oak Park',  'MI',  '48237',  'USA',  '``ben@forta.com``'); `|`INSERT INTO cust_new(cust_id,cust_name) `<br>`VALUES (1111111111,"MONSTER");`|**✅**|![image\.png](图片和附件/image%205.png)|0\.031s|
|2. 备份 Orders 表和 OrderItems 表。|`-- MySQL, MariaDB, Oracle, PostgreSQL, SQLite CREATE TABLE OrdersBackup AS SELECT * FROM Orders; CREATE TABLE OrderItemsBackup AS SELECT * FROM OrderItems; -- SQL Server SELECT * INTO OrdersBackup FROM Orders; SELECT * INTO OrderItemsBackup FROM OrderItems; `|`CREATE TABLE Orders_Copy `<br>`SELECT * FROM Orders;`<br>`CREATE TABLE OrderItems_Copy `<br>`SELECT * FROM OrderItems;`|**✅**|<br>![image\.png](图片和附件/image%2064.png)|0\.032s|

- 运行结果： 

- 错点：列和值顺序一致；INSERT SELECT 要求目标表已存在且类型兼容。 

- 费曼自测： 

    1. 人话：把新数据写进表，或从别的查询批量写表。 

    2. 绕路：Excel 导入，但定时ETL还是用SQL。 

    3. 业务：落维表、补商品属性、把分析结果回写统计表。 

### 第16课 更新和删除数据 

- 跟书动作：UPDATE、DELETE、带WHERE、事务安全 

- 书后挑战题：原书第16课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 美国各州的缩写应始终用大写。编写 SQL语句来更新所有美国地址，包 括供应商状态（Vendors 表中的 vend\_state）和顾客状态（Customers 表中的 cust\_state），使它们均为大写。|UPDATE Vendors<br>SET vend\_state = UPPER\(vend\_state\)<br>WHERE vend\_country = 'USA';<br>UPDATE Customers<br>SET cust\_state = UPPER\(cust\_state\)<br>WHERE vend\_country = 'USA';|SET SQL\_SAFE\_UPDATES = 0;  \-\- 关闭安全模式<br><br>UPDATE Vendors<br>SET vend\_state = UPPER\(vend\_state\)<br>WHERE vend\_country = 'USA';<br>UPDATE Customers<br>SET cust\_state = UPPER\(cust\_state\)<br>WHERE cust\_country = 'USA';<br><br>SET SQL\_SAFE\_UPDATES = 1;  \-\- 重新开启安全模式|**✅**|![image\.png](图片和附件/image%2022.png)<br>|0\.031s|
|2. 第 15 课的挑战题 1 要求你将自己添加到 Customers 表中。现在请删除 自己。确保使用 WHERE 子句（在 DELETE 中使用它之前，先用 SELECT 对其进行测试），否则你会删除所有顾客！|\-\- 首先测试 WHERE，确保它仅选择你要删除的内容。 SELECT \* FROM Customers WHERE cust\_id = 1000000042; \-\- 那就做吧！ DELETE Customers WHERE cust\_id = 1000000042; |SET SQL\_SAFE\_UPDATES = 0;  \-\- 关闭安全模式<br><br>SELECT \*<br>FROM Cust\_New<br>WHERE cust\_name = 'MONSTER';<br>DELETE <br>FROM Cust\_New<br>WHERE cust\_name = 'MONSTER';<br><br>SET SQL\_SAFE\_UPDATES = 1;  \-\- 重新开启安全模式|**✅**|![image\.png](图片和附件/image%2046.png)<br>|0\.032s|

- 运行结果： 

- 错点：UPDATE/DELETE 不加WHERE会全表改删；生产先SELECT确认，放事务里改。 

- 费曼自测： 

    1. 人话：改已有行、删不需要的行。 

    2. 绕路：Excel改完再导入，但容易破坏口径。 

    3. 业务：修正商品成本价、清理测试订单、维护维表。 

### 第17课 创建和操纵表 

- 跟书动作：CREATE TABLE、NULL/DEFAULT、主键外键、改表/删表/重命名 

- 书后挑战题：原书第17课挑战 

- 我的解决方案： 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. 在 Vendors 表中添加一个网站列（vend\_web）。你需要一个足以容纳 URL 的大文本字段。|`ALTER TABLE Vendors ADD vend_web CHAR(100); `|`SET SQL_SAFE_UPDATES = 0;  -- 关闭安全模式`<br><br>`ALTER TABLE Vendors`<br>`ADD vend_web TEXT NULL;`<br><br>`SET SQL_SAFE_UPDATES = 1;  -- 重新开启安全模式`|**✅**<br>|![image\.png](图片和附件/image%2010.png)<br>|0\.000s|
|2. 使用 UPDATE 语句更新 Vendor 记录，以便加入网站（你可以编造任 何地址）。|`UPDATE Vendors SET vend_web = '``https://google.com/'`` WHERE vend_id = 'DLL01';  `|`SET SQL_SAFE_UPDATES = 0;  -- 关闭安全模式`<br><br>`UPDATE Vendors`<br>`SET vend_web = '``www.buzhidao.com``'`<br>`WHERE vend_id LIKE '%01';`<br><br>`SET SQL_SAFE_UPDATES = 1;  -- 重新开启安全模式`|**✅**|![image\.png](图片和附件/image%2034.png)|0\.016s|

- 运行结果： 

- 错点：自增语法各库不同（MySQL AUTO\_INCREMENT、PG IDENTITY/SERIAL、SQL Server IDENTITY）；改表前备份。 

- 费曼自测： 

    1. 人话：建表就是定义列名、类型、主键外键和默认值。 

    2. 绕路：用Excel表代替，但多系统共享和约束做不到。 

    3. 业务：建商品维表、订单事实表、库存表，是指标体系落地前提。 

### 第18课 使用视图 

|**题目**|**标准答案**|**自己的答案**|**运行是否成功（✅成功 ❌报错 ➖未运行）**|运行截图|运行时长|
|---|---|---|---|---|---|
|1. \. 创建一个名为 CustomersWithOrders 的视图，其中包含 Customers 表中的所有列，但仅仅是那些已下订单的列。提示：可以在 Orders 表上使用 JOIN 来仅仅过滤所需的顾客，然后使用 SELECT 来确保拥 有正确的数据。|`CREATE VIEW CustomersWithOrders AS SELECT Customers.cust_id,  Customers.cust_name,  Customers.cust_address,  Customers.cust_city,  Customers.cust_state,  Customers.cust_zip,  Customers.cust_country,  Customers.cust_contact,  Customers.cust_email FROM Customers JOIN Orders ON Customers.cust_id = Orders.cust_id; SELECT * FROM CustomersWithOrders; `|`CREATE VIEW CustomersWithOrders AS`<br>`SELECT Customers.*`<br>`FROM Orders`<br>`LEFT JOIN Customers`<br>`ON Orders.cust_id = Customers.cust_id`|**✅**|![image\.png](图片和附件/image%2052.png)|0\.047s|
|2. 下面的 SQL 语句有问题吗？（尝试在不运行的情况下指出。）<br>    `CREATE VIEW OrderItemsExpanded AS SELECT order_num,  prod_id,  quantity,  item_price,  quantity*item_price AS expanded_price FROM OrderItems ORDER BY order_num;`|视图中不允许使用 ORDER BY。如果你想在从视图检索数据的 SELECT 中使用 ORDER BY 对数据进行排序，则视图的使用方式与表相同。<br>|无<br>|**✅**|![image\.png](图片和附件/image%2020.png)|0\.015s|

### 第19课 使用存储过程 

无习题，延伸阅读补充理解。
https://www\.jb51\.net/database/364657yk6\.htm中的存储过程部分

```SQL
DELIMITER //
CREATE PROCEDURE GetUserCount(OUT c_count INT)
BEGIN
    SELECT COUNT(*)
    INTO c_count
    FROM Customers;
END //
DELIMITER ;
-- 调用
CALL GetUserCount(@total);
SELECT @total AS user_count;
```

```SQL
DELIMITER //
CREATE PROCEDURE GetUserById(IN id CHAR(10))
BEGIN
    SELECT cust_id,cust_name
    FROM Customers
    WHERE cust_id = id;
END //
DELIMITER ;
-- 调用
CALL GetUserById(1000000001);
```

### 第20课 管理事务处理 

无习题，延伸阅读补充理解。

https://mianshidashi\.cn/interview\-questions/bytedance/backend\-development/database\-transaction\-acid

![image\.png](图片和附件/image%2071.png)

### 第21课 使用游标 

无习题，延伸阅读补充理解。

https://mp\.weixin\.qq\.com/s?src=11\&timestamp=1795017841\&ver=7096\&signature=3FiNOD\*9\-GMz60lKgwJxof37qiSHReWMXdGQUNxedglJWxyUjJIYd7L33e3jxiv81FUeX7yoHmuJ7l4kAv4QA1a0fkciiaDBT3Cc1eI7z2045gVreXD1\*Mo5U8D9WHHC\&new=1

```SQL
Dataset: Logistics & supply chain数据集：物流与供应链
Operations reviews shipments promised for 2025-07-01 (any time that day) that have not been delivered and are still active (created, in_transit or exception). Return id, reference, status and promised_by, earliest promise first.审核2025年7月1日（当天任意时间）承诺但尚未交付且仍处于活动状态（已创建、运输中或异常）的发货。返回退货ID、参考编号、状态及承诺人，按最早承诺时间排序。
A：
SELECT shipments.id, reference, status, promised_by
FROM shipments
WHERE promised_by >= '2025-07-01 00:00:00'
  AND promised_by <  '2025-07-02 00:00:00'
  AND status IN ('created', 'in_transit', 'exception')
ORDER BY promised_by ASC;
```

### 第22课 高级SQL特性 

```SQL
From next month, monthly plans cost 10% more per seat and annual plans 8% more, except the enterprise plan, which keeps its price, and the free plan (0.00). Update plans.seat_price in one statement, rounding new prices to 2 decimals.
A：
Update plans
SET seat_price = round(seat_price * 
  CASE billing_period WHEN 'monthly' THEN 1.10 
  ELSE 1.08 END, 2)
WHERE tier <> 'enterprise';
```

---

## 三、周度复盘 

### 2026\-38周（09\-14\~09\-20）

|**自然周**|**日期**|**学习章节**|**学习内容**|**书后挑战题**|**周间总结**|
|---|---|---|---|---|---|
|2026\-38周<br>（09\-14\~09\-20）|09\-17|第一章 1\-3节<br>|1、什么是数据库，什么是DBMS；<br>2、什么是SQL，什么是ANSI SQL；<br>3、练习SQL，安装DBMS VS 远程DBMS推荐；|1、无挑战题；<br>2、制作了一个学习模板，便于记录练习记录，同时也检测电脑自带MYSQL\+Workbence\+笔记本环境，便于后续练习题目；|1、理清了DBMS和SQL的概念。<br>2、准备好了刷题所需的环境，根据已有的条件选择了mysql适配的环境，无需重新安装。|
||09\-17|附录A 样本例脚本|1、样本数据库数据表设计和机构；<br>2、如何获取样本例；|1、无挑战题；<br>2、用已安装好的mysql workbence创建样例数据库并解决过程中的bug；||

### 2026\-42周（10\-12\~10\-17）

|**自然周**|**日期**|**学习章节**|**学习内容**|**书后挑战题**|**周间总结**|
|---|---|---|---|---|---|
|2026\-42周（10\-12\~10\-17）|10\-14|第二课 \+习题|SELECT 检索\+去重操作练习|第二课3道习题均做完|之前是浅浅学会了每一个语法和关键字的作用，这一次是从更深的角度来学习，所以能够看到第一次学习时看不到的层面，比如说，为何同一个功能比如说筛选会有不同的关键字来做，每一个关键字都在补充其他关键字做不到的事情，比如说\>=这种筛选只需要有下限，而BETWEEN需要有边界，不同的应用场景所需的做法不同。|
||10\-15|第三课\+习题|ORDER BY排序|第三课4道习题均做完||
||10\-17|第四课\+习题|WHERE过滤|第四课4道习题均做完||

### 2026\-43周（10\-19\~10\-25）

|**自然周**|**日期**|**学习章节**|**学习内容**|**书后挑战题**|**周间总结**|
|---|---|---|---|---|---|
|2026\-43周（10\-19\~10\-25）|10\-19|第五课 \+习题|WHERE高级检索操作练习|第五课4道习题均做完|习题做的很顺畅，但是记不住。|
||10\-20|第六课 \+习题|LIKE通配符% \_ \[\]|第六课4道习题均做完||
||10\-21|第七课\+习题|创建计算字段|第七课2道习题均做完||
||10\-22|第八课\+习题|使用函数处理数据|第八课2道习题均做完||

### 2026\-45周（11\-2\~11\-6）

|**自然周**|**日期**|**学习章节**|**学习内容**|**书后挑战题**|**周间总结**|
|---|---|---|---|---|---|
|2026\-45周（10\-19\~10\-25）|11\-3|第九课 \+习题|SUM、COUNT、MAX、MIN、AVG 聚合函数|第九课3道习题均做完|补充了很多编程细节，比如之前只是简单的记口诀，聚合后必须配合GROUP BY，GROUP BY 在 WHERE之前，HAVING在WHERE之后，理解原理之后对编写更复杂业务逻辑的SQL会更加得心应手，同时每日练习也能保持手感，时间还是花得值的，不要相信有什么速成的方法，只有持续练习才是真的。|
||11\-4|第十课\+习题|GROUP BY \+ HAVING分组函数|第十课5道习题均做完||
|||第十一课\+习题|IN 子查询的两种用法|第十一课5道习题均做完||
||11\-5|第十二课\+习题|等值联结和内联结|第十二课5道习题均做完||
||11\-6|第十三课\+习题|高级联结|第十三课5道习题均做完||

# 2026\-46周（11\-9\~11\-15）

|**自然周**|**日期**|**学习章节**|**学习内容**|**书后挑战题**|**周间总结**|
|---|---|---|---|---|---|
|2026\-46周（10\-19\~10\-25）|11\-9|第十四课 \+习题|UNION 组合查询|第十四课4道习题均做完|算是比较高级的内容，以往的工作中接触的不多，明显感觉到吃力了，如果要进阶数据库的话，这一部分会成为阻碍。|
||11\-10|第十五课\+习题|插入数据 INSERT、CREATE|第十五课2道习题均做完||
||11\-11|第十六课\+习题|UPDATE、DELETE更新数据|第十六课2道习题均做完||
||11\-12|第十七课\+习题|CREATE、ALTER、DROP表操作|第十七课2道习题均做完||
||11\-15|第十八课\+习题|CREATE VIEW创建视图|第十八课2道习题均做完||

# 2026\-47周（11\-16\~11\-20）

|**自然周**|**日期**|**学习章节**|**学习内容**|**书后挑战题**|**周间总结**|
|---|---|---|---|---|---|
|2026\-47周（10\-19\~10\-25）|11\-17|第十九课 \+习题|存储过程 PROCEDURE|无习题，延伸练习2道|![image\.png](图片和附件/image%2033.png)<br>高级内容学起来比较吃力，刷题也发现有很多不熟练的地方，虽然说写代码没问题，但要做更复杂的项目明显会拖慢进度，还是要keep practicing，keep learning。|
||11\-17|第二十课\+习题|事务处理TRANCATION|无习题，延伸阅读面经||
||11\-18|第二十一课\+习题|游标Cursor|无习题，延伸阅读\+练习||
||11\-19|第二十二课\+习题|高级特性|无习题，延伸阅读\+练习||
||11\-20|附录|关键字、数据类型、索引|无习题，延伸阅读\+练习<br>||



